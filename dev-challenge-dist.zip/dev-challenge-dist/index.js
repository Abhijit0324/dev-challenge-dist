/**
 * This javascript file will constitute the entry point of your solution.
 *
 * Edit it as you need.  It currently contains things that you might find helpful to get started.
 */

// This is not really required, but means that changes to index.html will cause a reload.
require('./site/index.html')
// Apply the styles in style.css to the page.
require('./site/style.css')
//const serverPublisher = require('./devserver/server-publisher')

// if you want to use es6, you can do something like
//     require('./es6/myEs6code')
// here to load the myEs6code.js file, and it will be automatically transpiled.

// Change this to get detailed logging from the stomp library
global.DEBUG = false

const url = "ws://localhost:8011/stomp"
const client = Stomp.client(url)

client.debug = function(msg) {
  if (global.DEBUG) {
    console.info(msg)
  }
}

function connectCallback() {
  //document.getElementById('stomp-status').innerHTML = "It has now successfully connected to a stomp server serving price updates for some foreign exchange currency pairs."
  var ArrayValue=[]
  var shouldSwitch = true;
  function callback (message) {
    // called when the client receives a STOMP message from the server

    if (message.body) {
       var table = document.getElementById("myTable");
       
       var obj = JSON.parse(message.body);
       let obj1 = ArrayValue.find(o => o.name === obj.name);
       
       if(obj1=== undefined)
       {
      
          ArrayValue.push(obj);
          
          let midPrice = ((obj.bestBid + obj.bestAsk)/2)
        
          var row = table.insertRow(1);
          var cell1 = row.insertCell(0);
          var cell2 = row.insertCell(1);
          var cell3 = row.insertCell(2);
          var cell4 = row.insertCell(3);
          var cell5 = row.insertCell(4);
          var cell6 = row.insertCell(5);
          let rows = table.rows ;
          cell6.id = 'myTd'+rows.length+1;
          cell1.innerHTML = obj.name;
          cell2.innerHTML = obj.bestBid;
          cell3.innerHTML = obj.bestAsk;
          cell4.innerHTML = obj.openBid;
          cell5.innerHTML = obj.lastChangeBid;
          Sparkline.draw(document.getElementById("myTd"+rows.length+1), [1, 2, 3, midPrice])

          while (shouldSwitch) {
          //start by saying: no switching is done:
          shouldSwitch = false;
          let rows = table.rows;
          /*Loop through all table rows (except the
          first, which contains table headers):*/
          for (i = 1; i < (rows.length - 1); i++) {
            //start by saying there should be no switching:
            shouldSwitch = false;
            /*Get the two elements you want to compare,
            one from current row and one from the next:*/
            x = rows[i].getElementsByTagName("td")[4];
            y = rows[i + 1].getElementsByTagName("td")[4];
            //check if the two rows should switch place:
            if (parseFloat(x.innerHTML)  > parseFloat(x.innerHTML) ) {
              //if so, mark as a switch and break the loop:
              shouldSwitch = true;
              break;
            }
          }
          if (shouldSwitch) {
            /*If a switch has been marked, make the switch
            and mark that a switch has been done:*/
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            shouldSwitch = true;
          }
        }
       }

     
    } else {
       alert("got empty message");
    }
  };
  
  var subscription = client.subscribe("/fx/prices", callback);
}

client.connect({}, connectCallback, function(error) {
  alert(error.headers.message)
})

